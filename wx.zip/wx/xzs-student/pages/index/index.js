//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    spinShow: false,
    fixedPaper: [],
    pushPaper: [],
    timeLimitPaper: [],
    taskList: [],
    shouyeTable: {
      newsCateArr: [
        { val: 1, label: '学校概况' }, // val 是唯一标识符，label 是显示文本
        { val: 2, label: '教育教学' },
        { val: 3, label: '学院学科' },
        { val: 4, label: '科学研究'},       
        { val: 5, label: '成绩查询' },
        { val: 6, label: '学生天地' },
        {val: 7, label: '选课报名' },
        { val: 8, label: '校园活动报名' },
        { val: 9, label: '我的课表' }
      ]
    },
  },
            // 跳转到对应页面
            navigateToPage: function (e) {
              // 获取点击的页面路径
              const url = e.currentTarget.dataset.url;
          
              // 跳转到对应页面
              wx.navigateTo({
                url: url
              });},
  onLoad: function() {
    this.setData({
      spinShow: true
    });
    this.indexLoad()
  },
  onPullDownRefresh() {
    this.setData({
      spinShow: true
    });
    if (!this.loading) {
      this.indexLoad()
    }
  },
  indexLoad: function() {
    let _this = this
    app.formPost('/api/wx/student/dashboard/index', null).then(res => {
      _this.setData({
        spinShow: false
      });
      wx.stopPullDownRefresh()
      if (res.code === 1) {
        _this.setData({
          fixedPaper: res.response.fixedPaper,
          timeLimitPaper: res.response.timeLimitPaper,
          pushPaper: res.response.pushPaper
        });
      }
    }).catch(e => {
      _this.setData({
        spinShow: false
      });
      app.message(e, 'error')
    })

    app.formPost('/api/wx/student/dashboard/task', null).then(res => {
      _this.setData({
        spinShow: false
      });
      wx.stopPullDownRefresh()
      if (res.code === 1) {
        _this.setData({
          taskList: res.response,
        });
      }
    }).catch(e => {
      _this.setData({
        spinShow: false
      });
      app.message(e, 'error')
    })
  }
})