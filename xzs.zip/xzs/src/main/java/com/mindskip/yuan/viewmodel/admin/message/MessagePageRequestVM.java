package com.mindskip.yuan.viewmodel.admin.message;

import com.mindskip.yuan.base.BasePage;



public class MessagePageRequestVM extends BasePage {
    private String sendUserName;

    public String getSendUserName() {
        return sendUserName;
    }

    public void setSendUserName(String sendUserName) {
        this.sendUserName = sendUserName;
    }
}
