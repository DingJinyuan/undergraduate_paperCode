// pages/news/news_1_details/news_1_details_5/news_1_details_5.js
Page({
  data: {
    news: {
      NEWS_TITLE: '生命科学学院召开2025年度国家自然科学基金项目申报点评会',
      NEWS_ADD_TIME: '2025-03-01',
      NEWS_CATE_NAME: '校园新闻',
      NEWS_CONTENT: [
        {
          type: 'text',
          val: `　　近日，生命科学学院在理工楼13号楼会议室召开2025年度国家自然科学基金项目申报点评会，学院副院长付新苗、原院长张彦定、原副院长陈由强担任点评专家。会议由付新苗主持。

          　　会上，项目申请人从项目的选题背景、研究目的、研究内容、技术路线、预期成果等方面进行详细汇报。与会专家从项目的科学性、创新性、可行性等多个角度出发，提出了宝贵意见和建议，并与申报教师们深入交流，帮助他们进一步理清思路，完善申报材料。现场气氛热烈，教师们踊跃参与互动，纷纷表示参加此次点评会受益匪浅。`
        },
        {
          type: 'img',
          val: '../../../../images/news/news_1/news_1_5.png'
        }
      ]
    }
  },
  onLoad: function() {
    // 这里可以对数据进行额外处理，如果有需要的话
    // 例如从缓存中获取数据覆盖当前默认数据
    // const cachedNews = wx.getStorageSync('cachedNews');
    // if (cachedNews) {
    //   this.setData({
    //     news: cachedNews
    //   });
    // }
  }
});