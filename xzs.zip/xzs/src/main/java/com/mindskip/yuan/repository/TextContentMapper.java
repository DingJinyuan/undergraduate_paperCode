package com.mindskip.yuan.repository;

import com.mindskip.yuan.domain.TextContent;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TextContentMapper extends BaseMapper<TextContent> {

}
