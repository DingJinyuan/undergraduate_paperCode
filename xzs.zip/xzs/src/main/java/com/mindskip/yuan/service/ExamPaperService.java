package com.mindskip.yuan.service;

import com.mindskip.yuan.domain.ExamPaper;
import com.mindskip.yuan.domain.User;
import com.mindskip.yuan.viewmodel.admin.exam.ExamPaperEditRequestVM;
import com.mindskip.yuan.viewmodel.admin.exam.ExamPaperPageRequestVM;
import com.mindskip.yuan.viewmodel.student.dashboard.PaperFilter;
import com.mindskip.yuan.viewmodel.student.dashboard.PaperInfo;
import com.mindskip.yuan.viewmodel.student.exam.ExamPaperPageVM;
import com.github.pagehelper.PageInfo;

import java.util.List;

public interface ExamPaperService extends BaseService<ExamPaper> {

    PageInfo<ExamPaper> page(ExamPaperPageRequestVM requestVM);

    PageInfo<ExamPaper> taskExamPage(ExamPaperPageRequestVM requestVM);

    PageInfo<ExamPaper> studentPage(ExamPaperPageVM requestVM);

    ExamPaper savePaperFromVM(ExamPaperEditRequestVM examPaperEditRequestVM, User user);

    ExamPaperEditRequestVM examPaperToVM(Integer id);

    List<PaperInfo> indexPaper(PaperFilter paperFilter);

    Integer selectAllCount();

    List<Integer> selectMothCount();
}
