// pages/news/news_1_details/news_1_details_4/news_1_details_4.js
Page({
  data: {
    news: {
      NEWS_TITLE: '我校在三明建成高精度大气温室气体观测站',
      NEWS_ADD_TIME: '2025-03-04',
      NEWS_CATE_NAME: '校园新闻',
      NEWS_CONTENT: [
        {
          type: 'text',
          val: `　　近日，我校三明森林生态系统国家野外科学观测研究站（三明国家站）与三明市气象局共建的福建省（三明市）高精度温室气体二氧化碳和甲烷浓度观测站正式投入运营。这是省内首个高精度温室气体长期监测点，标志着我省在地基温室气体长期监测领域取得突破性进展。

          　　该观测站依托三明国家站内已有的国家级标准气象场，新建了用于安装温室气体观测系统的采样管、常规气象要素和三维超声风速仪等观测设备的35m高观测铁塔、气体分析室，实现对大气二氧化碳和甲烷等温室气体浓度的连续自动监测，形成了完整的数据采集、传输和分析体系。`
        },
        {
          type: 'img',
          val: '../../../../images/news/news_1/news_1_4.png'
        }
      ]
    }
  },
  onLoad: function() {
    // 这里可以对数据进行额外处理，如果有需要的话
    // 例如从缓存中获取数据覆盖当前默认数据
    // const cachedNews = wx.getStorageSync('cachedNews');
    // if (cachedNews) {
    //   this.setData({
    //     news: cachedNews
    //   });
    // }
  }
});