Page({
  data: {
    newsList: [], // 新闻列表
    searchKeyword: '', // 搜索关键词
    originalNewsList: [] // 原始新闻列表（用于搜索时恢复数据）
  },

  onLoad: function () {
    // 初始化新闻数据
    this.initNewsData();
  },

  // 初始化新闻数据
  initNewsData: function () {
    const newsList = [
      {
        id: 1,
        news_title: '计算机与网络空间安全学院',
        news_summary: "福建师范大学计算机与网络空间安全学院是培养未来数字时代守护者的摇篮，致力于技术创新与网络安全的前沿探索。",
        news_img: '../../../images/news/news_3/news_3_1.jpg',
        news_time: '2025-03-01',
        news_url: 'https://ccs.fjnu.edu.cn' 
      },
      {
        id: 2,
        news_title: '数学与统计学院',
        news_summary: '福建师范大学数学与统计学院是逻辑与数据的交汇之地，培养着严谨思维与创新能力的数学与统计精英，为科学与技术发展提供坚实的理论支撑。',
        news_img: '../../../images/news/news_3/news_3_2.webp',
        news_time: '2025-03-03',
        news_url: 'https://math.fjnu.edu.cn' 
      },
      {
        id: 3,
        news_title: '马克思主义学院',
        news_summary: '福建师范大学马克思主义学院是思想与信仰的灯塔，致力于培养具有坚定理想信念和深厚理论素养的时代新人。',
        news_img: '../../../images/news/news_3/news_3_3.jpg',
        news_time: '2025-03-05',
        news_url: 'https://mkszyxy.fjnu.edu.cn' 
      },
      {
        id: 4,
        news_title: '美术学院',
        news_summary: '福建师范大学美术学院是艺术与创意的殿堂，孕育着无数才华横溢的艺术家，将传统美学与现代设计完美融合。',
        news_img: '../../../images/news/news_3/news_3_4.jpg',
        news_time: '2025-03-04',
        news_url: 'https://art.fjnu.edu.cn' 
      },
      {
        id: 5,
        news_title: '体育科学学院',
        news_summary: '福建师范大学体育学院是活力与拼搏的象征，培养着身心健康、意志坚定的体育英才，为体育强国梦注入青春力量。',
        news_img: '../../../images/news/news_3/news_3_5.png',
        news_time: '2025-03-04',
        news_url: 'https://tky.fjnu.edu.cn' }
    ];

    // 设置新闻列表和原始新闻列表
    this.setData({
      newsList: newsList,
      originalNewsList: newsList
    });
  },

  // 处理搜索框点击事件
  handleSearchTap: function () {
    wx.showToast({
      title: '点击了搜索框',
      icon: 'none'
    });
  },

  // 处理新闻项点击事件
  handleItemTap: function (e) {
    const url = e.currentTarget.dataset.url;
    console.log('即将传递的 url:', url);
    if (url) {
        const encodedUrl = encodeURIComponent(url);
        console.log('编码后的 url:', encodedUrl);
        wx.navigateTo({
            url: `/pages/news/webview/webview?url=${encodedUrl}`,
            success: function () {
                console.log('跳转成功');
            },
            fail: function (err) {
                console.error('跳转失败:', err);
            }
        });
    }
},

  // 处理图片加载错误
  handleImageError: function (e) {
    const index = e.currentTarget.dataset.index;
    console.error(`图片加载失败，索引: ${index}`);
  },

  // 处理搜索输入
  handleSearchInput: function (e) {
    const keyword = e.detail.value.trim(); // 获取搜索关键词
    this.setData({
      searchKeyword: keyword
    });

    // 过滤新闻列表
    this.filterNewsList(keyword);
  },

  // 根据关键词过滤新闻列表
  filterNewsList: function (keyword) {
    const { originalNewsList } = this.data;
    if (!keyword) {
      // 如果关键词为空，恢复原始数据
      this.setData({
        newsList: originalNewsList
      });
      return;
    }

    // 过滤新闻列表
    const filteredList = originalNewsList.filter(item => {
      return (
        item.news_title.includes(keyword) || item.news_summary.includes(keyword)
      );
    });

    // 更新新闻列表
    this.setData({
      newsList: filteredList
    });
  }
});