package com.mindskip.yuan.base;



public abstract class BaseEntity {

}
