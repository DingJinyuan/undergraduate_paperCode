Page({
  data: {
    inputmsg: '', // 存放用户输入内容
    chatHistory: [], // 存放聊天记录
    wenxin_acc: '' // 存放文心模型的 access_token
  },

  onLoad(options) {
    this.getwenxin(); // 获取文心模型的 access_token
  },

  // 获取用户输入内容
  getmsg(msg) {
    this.setData({
      inputmsg: msg.detail.value
    });
  },

  // 获取文心模型的 access_token
  getwenxin() {
    var that = this;
    const wenxin_url =
      'https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=icjtid5OmLjXCxjwEW2sBxYd&client_secret=Kza1DKod3dpyyyb25ppommyKbeCTNPFQ';

    wx.request({
      url: wenxin_url,
      header: {
        'Content-Type': 'application/json'
      },
      method: 'POST',
      timeout: 10000, // 设置超时时间为 10 秒
      success: (res) => {
        console.log(res);
        that.setData({
          wenxin_acc: res.data.access_token
        });
      },
      fail: (err) => {
        console.error('获取 access_token 失败', err);
        wx.showToast({
          title: '网络请求失败，请重试',
          icon: 'none'
        });
      }
    });
  },

  // 向文心模型发送问题并获取回答
  getAnswer() {
    var that = this;
    const wenxin_url =
      'https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/completions_pro?access_token=' +
      this.data.wenxin_acc;

    const question = {
      messages: [
        {
          role: 'user',
          content: that.data.inputmsg
        }
      ],
      temperature: 0.95,
      top_p: 0.8,
      penalty_score: 1,
      enable_system_memory: false,
      disable_search: false,
      enable_citation: false
    };

    // 将用户输入添加到聊天记录
    that.setData({
      chatHistory: [
        ...that.data.chatHistory,
        { role: 'user', content: that.data.inputmsg }
      ],
      inputmsg: '' // 清空输入框
    });

    wx.request({
      url: wenxin_url,
      method: 'POST',
      data: question,
      header: { 'Content-Type': 'application/json' },
      timeout: 100000, // 设置超时时间为 100 秒
      success: (res) => {
        console.log(res.data);
        // 将文心模型的回答添加到聊天记录
        that.setData({
          chatHistory: [
            ...that.data.chatHistory,
            { role: 'bot', content: res.data.result }
          ]
        });
      },
      fail: (err) => {
        console.error('请求失败', err);
        wx.showToast({
          title: '请求超时，请重试',
          icon: 'none'
        });
      }
    });
  },

  // 清空输入框
  clearInput() {
    this.setData({
      inputmsg: ''
    });
  }
});