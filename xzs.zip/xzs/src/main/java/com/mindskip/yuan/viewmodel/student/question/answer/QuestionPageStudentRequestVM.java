package com.mindskip.yuan.viewmodel.student.question.answer;

import com.mindskip.yuan.base.BasePage;

public class QuestionPageStudentRequestVM extends BasePage {
    private Integer createUser;

    public Integer getCreateUser() {
        return createUser;
    }

    public void setCreateUser(Integer createUser) {
        this.createUser = createUser;
    }
}
