// pages/news/webview/webview.js
Page({
  data: {
      currentUrl: ''
  },
  onLoad: function (options) {
      const encodedUrl = options.url;
      console.log('接收到的编码后的 url:', encodedUrl);
      const url = decodeURIComponent(encodedUrl);
      console.log('解码后的 url:', url);
      this.setData({
          currentUrl: url
      });
  }
});