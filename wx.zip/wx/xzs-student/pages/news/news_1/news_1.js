Page({
  data: {
    newsList: [], // 新闻列表
    searchKeyword: '', // 搜索关键词
    originalNewsList: [] // 原始新闻列表（用于搜索时恢复数据）
  },

  onLoad: function () {
    // 初始化新闻数据
    this.initNewsData();
  },

  // 初始化新闻数据
  initNewsData: function () {
    const newsList = [
      {
        id: 1,
        news_title: '福建省委常委、福州市委书记郭宁宁、市长吴贤德一行来校调研',
        news_summary: "2月28日，福建省委常委、福州市委书记郭宁宁、市长吴贤德带领福州市委常委、副市长张定锋，福州市委常委、市委秘书长郑彧及市委办、市政府办、市教育局、科技局、工信局、大学城管委会有关负责同志来我校调研。校党委书记潘玉腾，党政办公室、光电与信息工程学院负责人以及教师代表陪同调研。",
        news_img: '../../../images/news/news_1/news_1_1.jpg',
        news_time: '2025-03-01'
      },
      {
        id: 2,
        news_title: '台湾世新大学校长陈清河一行来校访问',
        news_summary: '2月28日，台湾世新大学校长陈清河、副校长李功勤等一行来校访问，校长郑家建、副校长欧阳松应会见了来宾一行。党政办公室、台港澳事务办公室、传播学院、文化旅游与公共管理学院等有关单位负责人参加会见。',
        news_img: '../../../images/news/news_1/news_1_2.jpg',
        news_time: '2025-03-03'
      },
      {
        id: 3,
        news_title: '新加坡南洋理工大学拉惹勒南国际研究院莅校调研',
        news_summary: '2月27日，新加坡南洋理工大学拉惹勒南国际研究院（RSIS）国防与战略研究所副所长陈大伦、研究生院负责人李明江、国际关系理学硕士项目副主任何子恩、美国项目副研究员陈贤安和暨南大学东南亚研究中心主任张云莅校调研。校社科处处长张梅，社会历史学院党委书记陈尚旺、院长孙建党，外国语学院副院长尤泽顺等参与交流。',
        news_img: '../../../images/news/news_1/news_1_3.png',
        news_time: '2025-03-05'
      },
      {
        id: 4,
        news_title: '我校在三明建成高精度大气温室气体观测站',
        news_summary: '近日，我校三明森林生态系统国家野外科学观测研究站（三明国家站）与三明市气象局共建的福建省（三明市）高精度温室气体二氧化碳和甲烷浓度观测站正式投入运营。这是省内首个高精度温室气体长期监测点，标志着我省在地基温室气体长期监测领域取得突破性进展。',
        news_img: '../../../images/news/news_1/news_1_4.png',
        news_time: '2025-03-04'
      },
      {
        id: 5,
        news_title: '生命科学学院召开2025年度国家自然科学基金项目申报点评会',
        news_summary: '近日，生命科学学院在理工楼13号楼会议室召开2025年度国家自然科学基金项目申报点评会，学院副院长付新苗、原院长张彦定、原副院长陈由强担任点评专家。会议由付新苗主持。',
        news_img: '../../../images/news/news_1/news_1_5.png',
        news_time: '2025-03-04'
      }
    ];

    // 设置新闻列表和原始新闻列表
    this.setData({
      newsList: newsList,
      originalNewsList: newsList
    });
  },

  // 处理搜索框点击事件
  handleSearchTap: function () {
    wx.showToast({
      title: '点击了搜索框',
      icon: 'none'
    });
  },

  // 处理新闻项点击事件
  handleItemTap: function (e) {
    const id = e.currentTarget.dataset.id;
    // 生成新闻详情页面的路径
    const detailPagePath = `pages/news/news_1_details/news_1_details_${id}/news_1_details_${id}`;
    // 跳转到新闻详情页面
    wx.navigateTo({
      url: `/${detailPagePath}`
    });
  },

  // 处理图片加载错误
  handleImageError: function (e) {
    const index = e.currentTarget.dataset.index;
    console.error(`图片加载失败，索引: ${index}`);
  },

  // 处理搜索输入
  handleSearchInput: function (e) {
    const keyword = e.detail.value.trim(); // 获取搜索关键词
    this.setData({
      searchKeyword: keyword
    });

    // 过滤新闻列表
    this.filterNewsList(keyword);
  },

  // 根据关键词过滤新闻列表
  filterNewsList: function (keyword) {
    const { originalNewsList } = this.data;
    if (!keyword) {
      // 如果关键词为空，恢复原始数据
      this.setData({
        newsList: originalNewsList
      });
      return;
    }

    // 过滤新闻列表
    const filteredList = originalNewsList.filter(item => {
      return (
        item.news_title.includes(keyword) || item.news_summary.includes(keyword)
      );
    });

    // 更新新闻列表
    this.setData({
      newsList: filteredList
    });
  }
});